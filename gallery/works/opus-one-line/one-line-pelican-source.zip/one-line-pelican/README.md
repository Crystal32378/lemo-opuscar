# 一筆 · One Line — source

A 15-second one-line drawing of a pelican, made in code with the Lemo-Opuscar toolkit's One-line Drawing style.

To rebuild, put this folder at `films/one-line-pelican/` inside a clone of the Lemo-Opuscar library
(Crystal32378/lemo-opuscar), then from the library root:

    sh plugin/skills/lemo-opuscar/scripts/setup.sh deps
    sh tools/fetch.sh instruments vsco2ce
    sh films/one-line-pelican/build.sh

Needs Node 20+, Python 3.11+ (or uv) and ffmpeg 7+. The pages load `/core/lib.js` from the library root.
`TREATMENT.md` is the plan (in Traditional Chinese); `pelican.js` is the whole drawing; `CREDITS` lists every source.

## Licence

- `geom.js`, `ink.js`, `paper.js`, `cam.js` and `hands.js` are adapted from the One-line Drawing engine of
  Lemo-Opuscar, Copyright (c) 2026 LemoLab, under the MIT licence. Its full text is in `LICENSE` and must stay with
  these files. Each of them says so in its first line.
- The rest of the code here (`pelican.js`, `shots.js`, `main.js`, `index.html`, `mix.py`, `music/score.py`,
  `build.sh`) was written for this film and is offered under the same MIT terms.
- The clarinet samples the score plays are not in this folder; they are CC0 (see `CREDITS`).
