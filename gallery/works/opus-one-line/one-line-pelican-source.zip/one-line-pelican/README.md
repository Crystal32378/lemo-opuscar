# 一筆 · One Line — source

A 15-second one-line drawing of a pelican, made in code with the Lemo-Opuscar toolkit's One-line Drawing style.

To rebuild, put this folder at `films/one-line-pelican/` inside a clone of the Lemo-Opuscar library
(Crystal32378/lemo-opuscar), then from the library root:

    sh plugin/skills/lemo-opuscar/scripts/setup.sh deps
    sh tools/fetch.sh instruments vsco2ce
    sh films/one-line-pelican/build.sh

Needs Node 20+, Python 3.11+ (or uv) and ffmpeg 7+. The pages load `/core/lib.js` from the library root.
`TREATMENT.md` is the plan (in Traditional Chinese); `pelican.js` is the whole drawing; `CREDITS` lists every source.
