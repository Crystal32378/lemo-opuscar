"""Solo clarinet: one unbroken melodic line, written to the drawing (TREATMENT.md, cue map). 96 BPM, one beat = 0.625 s.
Short notes on the wave crests, a legato climb up the back and neck, a fast run along the beak that lands on the hook,
the music falls silent while the pen rests (score and reverb zeroed; the mix keeps a faint room tone), the highest note at the bottom of the gold pouch, then a descent back to the water.
python music/score.py → music/score.wav + music/cues.json"""
import sys, os, json, numpy as np, soundfile as sf
HERE = os.path.dirname(os.path.abspath(__file__))
LIB = os.environ.get('LIB') or os.path.abspath(os.path.join(HERE, '../../..'))
sys.path.insert(0, LIB)
from core.audio import sampler as S
from core.audio.sfx import SR, add

E = json.load(open(os.path.join(HERE, '..', 'events.json')))
DUR = E['dur'] + 0.6
S.seed(5)
B = 0.625
buf = np.zeros((int(DUR * SR), 2), np.float32)
PAN = 0.1     # one player, just right of centre

def stac(t, p, v=.5, g=1.0):
    add(buf, S.note('clarinet_stac', p, .5, vel=v), t, g, PAN)

def legato(notes, attack=.08, overlap=.08, tail=.6, g=1.0, first_attack=None):
    """notes = [(t, pitch, vel)]: each lasts to the next onset + overlap (a slur, no gaps)"""
    for i, (t, p, v) in enumerate(notes):
        t1 = notes[i + 1][0] + overlap if i + 1 < len(notes) else t + tail
        a = first_attack if (i == 0 and first_attack) else attack
        add(buf, S.note('clarinet', p, max(.15, t1 - t), vel=v, attack=a, release=.35), t, g, PAN)

cues = {}
# 1. the sea: one short note per crest (crests are pinned to beats 0…4 in pelican.js)
for k, p in enumerate(['D4', 'F#4', 'A4', 'F#4', 'B4']):
    stac(k * B, p, .44 + .03 * k, 2.2)
# 2. the tail curls up, the long back, the S of the neck: one slurred climb
legato([(3.0, 'A4', .46), (3.75, 'B4', .48), (4.375, 'D5', .52), (5.0, 'E5', .5), (5.625, 'D5', .46), (5.95, 'B4', .40)], first_attack=.12, tail=.5)
# 3. the eye: almost nothing, one soft low note (the first near-silence)
legato([(6.25, 'A4', .26)], first_attack=.15, tail=.45, g=.8)
# 4. the dash along the beak: a quick run up, landing exactly on the hook
run = [(6.875, 'D5'), (7.03, 'E5'), (7.19, 'F#5'), (7.345, 'A5')]
for t, p in run: stac(t, p, .5, 1.8)
stac(7.5, 'B5', .62, 2.0); cues['tip'] = 7.5
# 5. silence 7.5 → 9.375 (the pen rests on the hook; the music bus, reverb included, goes to zero below)
cues['silence'] = [7.62, 9.375]
# 6. the pouch: a soft pickup as the pen sets down again, the highest note of the film at the bottom of the gold curve
legato([(9.375, 'A5', .34), (10.0, 'D6', .5), (11.25, 'B5', .5), (11.875, 'A5', .46)], first_attack=.25, overlap=.12, g=.75)
cues['pouchLow'] = 10.0
# 7. down the neck to the water, then the line runs away: a descent, and the last long note
legato([(12.5, 'F#5', .46), (12.8, 'E5', .44), (13.05, 'D5', .42), (13.3, 'B4', .40), (13.55, 'A4', .40), (13.75, 'D4', .42)], overlap=.06, tail=1.6)
cues['final'] = 13.75

mix = S.room(buf, size=.5, mix=.2)
a, b = cues['silence']; i0, i1 = int(a * SR), int(b * SR); f = int(.08 * SR)
g = np.ones(len(mix), np.float32); g[i0:i1] = 0; g[i0 - f:i0] = np.linspace(1, 0, f)
g[i1:i1 + int(.02 * SR)] = np.linspace(0, 1, int(.02 * SR))
mix *= g[:, None]
# the last note fades out with the picture
e0, e1 = int(14.4 * SR), int(15.0 * SR); fade = np.ones(len(mix), np.float32); fade[e0:e1] = np.linspace(1, 0, e1 - e0) ** 1.5; fade[e1:] = 0
mix *= fade[:, None]
mix = mix / (np.abs(mix).max() + 1e-9) * .8
sf.write(os.path.join(HERE, 'score.wav'), mix, SR)
json.dump(cues, open(os.path.join(HERE, 'cues.json'), 'w'), indent=1)
print('score.wav', round(len(mix) / SR, 2), 's', cues)
print('\n'.join(S.credits(['clarinet', 'clarinet_stac'])))
