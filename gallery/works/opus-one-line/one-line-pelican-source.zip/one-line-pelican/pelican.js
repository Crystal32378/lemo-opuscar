// The whole film is this one line: the sea, a pelican, and the sea again.
// World units, y down. The water line is y = 0; the pelican floats on it, facing right.
// Each chapter: SVG path strings (absolute coordinates), a time window, marks (beats) and holds (the pen stops).

export const WL = 220, AMP = 12;          // wave length and height of the sea line

// A sea line from x0 to x1 at height 0: smooth half-waves, crests up (negative y). Returns the d string and the crest points.
function sea(x0, x1, amp = AMP, wl = WL) {
  let d = `M${x0},0`, x = x0, up = true;
  const crests = [];
  while (x + wl / 2 <= x1 + 0.01) {
    const s = up ? -1 : 1, a = amp * 1.33 * s, h = wl / 2;
    d += ` C${x + h / 3},${a} ${x + 2 * h / 3},${a} ${x + h},0`;
    if (up) crests.push([x + h / 2, -amp]);
    x += h; up = !up;
  }
  return { d, crests, end: x };
}

const B = 0.625;                          // one beat at 96 BPM

// --- the sea coming in (the pen is already running when the film starts) ---
const IN = sea(-2640, -440);
// crests land on beats: the first crest on screen sits on t = 0, then one per beat
const inMarks = IN.crests.slice(-5).map((c, k) => ({ at: c, r: 6, t: +(k * B).toFixed(3) }));

// --- the sea going out, to the right edge and beyond ---
const OUT = sea(280, 1960, 11);

export const SEGS = [
  { id: 'sea', style: 'sea', t: [-4.6, 3.0], slowK: 0.6,
    parts: [{ d: IN.d }, { d: `M${IN.end},0 C${IN.end + 30},-2 -386,-22 -392,-52 C-394,-62 -399,-71 -406,-79` }],
    marks: inMarks },
  // tail tip → the long arc of the back → the base of the neck
  { id: 'back', style: 'bird', t: [3.0, 4.4],
    parts: [{ d: 'M-406,-79 C-366,-82 -300,-122 -200,-150 C-110,-176 -12,-178 40,-168' }] },
  // the back of the neck: an S that rises to the back of the head
  { id: 'neck', style: 'bird', t: [4.4, 5.9],
    parts: [{ d: 'M40,-168 C72,-162 90,-206 72,-256 C52,-306 24,-382 68,-414' }] },
  // crown, then the eye (a small loop just inside the forehead), then the base of the beak
  { id: 'head', style: 'bird', t: [5.9, 6.75], slowK: 3.2,
    parts: [{ d: 'M68,-414 C90,-432 120,-434 138,-421 C143,-417 143,-411 138,-408 a7,7 0 1,0 -14,0 a7,7 0 1,0 14,0 C141,-405 147,-403 154,-402' }] },
  // the upper edge of the beak: the fastest stroke, ending in the small hook at the tip
  { id: 'beak', style: 'bird', t: [6.75, 7.5], slowK: 1.2,
    parts: [{ d: 'M154,-402 C240,-396 380,-362 486,-332 C496,-328 498,-320 489,-315' }] },
  // the pouch, in gold: the pen rests on the hook (the stop), then the slowest stroke of the film sags back to the throat
  { id: 'pouch', style: 'pouch', t: [7.5, 12.0], slowK: 1.0,
    parts: [{ d: 'M489,-315 C430,-312 378,-280 318,-246 C268,-218 200,-222 172,-256 C162,-270 154,-290 146,-298' }],
    holds: [{ f: 0, t: 7.5, dur: 1.875 }],
    marks: [{ f: 0.52, t: 10.0 }] },
  // the front of the neck and the breast, down to the water
  { id: 'front', style: 'bird', t: [12.0, 12.8],
    parts: [{ d: 'M146,-298 C138,-306 128,-296 128,-276 C128,-232 132,-196 160,-160 C200,-110 248,-62 262,-22 C266,-10 270,-2 280,0' }] },
  // and the sea again, running out of the picture
  { id: 'away', style: 'away', t: [12.8, 14.45], slowK: 0.4,
    parts: [{ d: OUT.d }] },
];

// times the score and the mix need
export const CUE = { tip: 7.5, resume: 9.375, pouchLow: 10.0, water: 12.8, exit: 14.45 };
