#!/bin/sh
# One command, from nothing to the film: events → score → mix → frames → mux (−14 LUFS, grain 0) → poster.
# Needs the library's core tier (setup.sh deps), the vsco2ce samples (sh tools/fetch.sh instruments vsco2ce) and ffmpeg 7+.
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
LIB=${LIB:-$(cd "$HERE/../.." && pwd)}          # clone mode: <repo>/films/<name>/
export LIB
[ -f "$LIB/core/render/video.mjs" ] || { echo "set LIB to the library folder"; exit 1; }
cd "$LIB"
node core/render/events.mjs "$HERE"
"$LIB/.venv/bin/python" "$HERE/music/score.py"
"$LIB/.venv/bin/python" "$HERE/mix.py"
node core/render/video.mjs "$HERE" --fps 24 --workers 4 --out "$HERE/out/video.mp4"
sh core/render/mux.sh "$HERE/out/video.mp4" "$HERE/out/mix.wav" "$HERE/one-line-pelican.mp4" 24 0
node core/render/still.mjs "$HERE" 14.9 --q nopen=1 --out "$HERE/out/poster" --prefix p_
cp "$HERE/out/poster/p_14.9.jpg" "$HERE/poster.jpg"
echo "done: $HERE/one-line-pelican.mp4"
