import { buildPath, headAt, posAt } from './geom.js';
import { SEGS, CUE } from './pelican.js';
import { prepare, drawLine, drawBlots } from './ink.js';
import { makePaper, drawPaper, vignette, makeTooth, drawTooth } from './paper.js';
import { camAt, worldToScreen, BASE } from './cam.js';
import { CAM } from './shots.js';
import { penShadow } from './hands.js';
import { clamp } from '/core/lib.js';

const DUR = 15.0;
const q = new URLSearchParams(location.search);
const cv = document.getElementById('c'), ctx = cv.getContext('2d');
const W = cv.width, H = cv.height;

const P = prepare(buildPath(SEGS));
const paper = makePaper(), tooth = makeTooth();
window.PATH = P;

function camFor(t) {
  let cam = camAt(P, CAM, t, W, H);
  const fixed = (x, y, z) => ({ cx: x, cy: y, k: BASE * z, r: 0, z });
  if (q.get('cam')) cam = fixed(...q.get('cam').split(',').map(Number));
  if (q.get('cams')) { const L = q.get('cams').split(';'); cam = fixed(...L[Math.min(L.length - 1, Math.floor(t))].split(',').map(Number)); }
  return cam;
}

// the pen is held by a right hand above the paper, leaning to the lower right
const DIR = [0.56, 0.83];

function render(t) {
  const cam = camFor(t);
  const M = worldToScreen(cam, W, H);
  drawPaper(ctx, paper, cam, W, H);
  const head = q.has('all') ? P.N - 1 : headAt(P, t);
  if (q.has('all') || t >= P.T[0]) drawLine(ctx, P, head, M, cam.k);
  drawBlots(ctx, P, q.has('all') ? 999 : t, M, cam.k);
  drawTooth(ctx, tooth, cam, W, H);
  vignette(ctx, W, H);
  if (!q.has('nopen') && !q.has('all') && t < CUE.exit) {
    // the pen leaves with the line: once the nib is past the right edge its shadow goes with it
    penShadow(ctx, M(...posAt(P, head)), DIR, cam.k, { alpha: 1 });
  }
}

// events for the mix: the pen-speed track (200 Hz), the stop, the restart and the exit
function events() {
  const ev = [], track = [];
  for (let t = 0; t <= DUR; t += 0.005) {
    const h = headAt(P, t), i = Math.floor(h), cam = camAt(P, CAM, t, W, H), M = worldToScreen(cam, W, H);
    const p = M(...posAt(P, h)), onPaper = p[0] > -40 && p[0] < W + 40;
    const moving = t > P.T[0] && t < P.T[P.N - 1] && !(t > CUE.tip && t < CUE.resume);
    track.push([+t.toFixed(3), moving && onPaper ? Math.round(P.V[i]) : 0, +clamp(p[0] / W, -0.2, 1.2).toFixed(3), P.segs[P.SEG[i]].style]);
  }
  ev.push({ t: 0, type: 'track', data: track });
  P.blots.forEach(b => ev.push({ t: b.t0, type: 'blot', dur: b.dur }));
  ev.push({ t: CUE.resume, type: 'resume' });
  P.segs.forEach(s => ev.push({ t: s.t[0], type: 'seg', id: s.id, t1: s.t[1] }));
  return ev;
}

window.DUR = DUR;
window.EV = events();
window.render = render;
window.READY = true;
