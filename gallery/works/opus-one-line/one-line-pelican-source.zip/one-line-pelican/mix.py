"""Mix: the pen on paper (synthesised from the pen-speed track, panned with the nib) + the pen setting down again after the
stop + a wet swell for the blot + room tone + the solo clarinet. No voice. At the stop the music (reverb included) goes to
zero; what remains is the room tone at 10 % and the faint swell of the blot, about −45 dB RMS in the finished film.
python mix.py → out/mix.wav (48 kHz stereo; loudness is left to the two-pass loudnorm in mux)"""
import sys, os, json, numpy as np, soundfile as sf
HERE = os.path.dirname(os.path.abspath(__file__))
LIB = os.environ.get('LIB') or os.path.abspath(os.path.join(HERE, '../..'))
sys.path.insert(0, LIB)
from core.audio.sfx import SR, add, bp, lp, limit

E = json.load(open(os.path.join(HERE, 'events.json'))); ev = E['ev']
DUR = E['dur'] + 0.3
N = int(DUR * SR)
rng = np.random.default_rng(23)
get = lambda typ: [e for e in ev if e['type'] == typ]
track = get('track')[0]['data']                       # [t, speed, screen x (0..1), style]
cues = json.load(open(os.path.join(HERE, 'music', 'cues.json')))

def smooth(x, ms):
    n = max(1, int(SR * ms / 1000)); return np.convolve(x, np.ones(n) / n, 'same')

# ---------- the pen on paper ----------
tt = np.array([r[0] for r in track]); v = np.array([r[1] for r in track], float); px = np.array([r[2] for r in track])
T = np.arange(N) / SR
V = np.interp(T, tt, v); PX = np.interp(T, tt, px)
amp = smooth(np.clip(V / 520, 0, 1.6) ** 0.5, 30)
grain = np.zeros(N)
dens = np.clip(V / 520, 0, 2) * 90 + (V > 5) * 25
hits = rng.random(N) < dens / SR
idx = np.nonzero(hits)[0]; grain[idx] = rng.standard_normal(len(idx)) * (0.5 + rng.random(len(idx)))
grain = bp(grain, 2500, 9000, 2)
white = rng.standard_normal(N)
bright = np.clip(V / 700, 0, 1)
scr = amp * ((0.55 + 0.45 * bright) * bp(white, 2200, 7500, 2) + (1 - bright) * 0.8 * bp(white, 700, 2400, 2)) + amp * 1.6 * grain
scr = lp(scr, 9000, 2) * 0.092          # about −3 dB under the demo's level: the clarinet carries the line here
pan = np.clip((PX - .5) * 1.2, -1, 1)
pen = np.stack([scr * np.sqrt(np.clip(.5 - pan / 2, 0, 1)), scr * np.sqrt(np.clip(.5 + pan / 2, 0, 1))], 1).astype(np.float32)

sfx = np.zeros((N, 2), np.float32)
sfx += pen
# the blot: a barely audible wet swell while the ink spreads under the resting nib
for e in get('blot'):
    d = int(1.6 * SR); t = np.arange(d) / SR
    wet = lp(rng.standard_normal(d), 800, 2) * np.sin(np.pi * np.clip(t / 1.6, 0, 1)) ** 2
    add(sfx, (wet * .02).astype(np.float32), e['t'] + .05, 1.0, .25)
# the pen sets down again: a small dry "sha" on the paper, the first sound after the silence
for e in get('resume'):
    d = int(.18 * SR); t = np.arange(d) / SR
    sha = bp(rng.standard_normal(d), 1800, 7000) * np.exp(-t / .045) * .9 + np.sin(2 * np.pi * 180 * t) * np.exp(-t / .02) * .25
    add(sfx, (sha * .16).astype(np.float32), e['t'] - .01, 1.0, .25)

# room tone, very faint; down to 10 % in the silence so the stop is really quiet
room = lp(np.cumsum(rng.standard_normal(N)) * .002, 400, 2); room = room - smooth(room, 500)
room = (room / (np.abs(room).max() + 1e-9) * .004).astype(np.float32)
s0, s1 = cues['silence']
gate = np.ones(N, np.float32); i0, i1 = int((s0 + .15) * SR), int((s1 - .25) * SR); gate[i0:i1] = .1
gate = smooth(gate, 120).astype(np.float32)
sfx += np.stack([room, room], 1) * gate[:, None]

# ---------- music ----------
mus, _ = sf.read(os.path.join(HERE, 'music', 'score.wav')); mus = mus.astype(np.float32)
m = np.zeros((N, 2), np.float32); n = min(N, len(mus)); m[:n] = mus[:n]

mix = m * .5 + sfx * 1.0
end = int(15.0 * SR); mix[end:] = 0
mix = limit(mix, .95)
os.makedirs(os.path.join(HERE, 'out'), exist_ok=True)
sf.write(os.path.join(HERE, 'out', 'mix.wav'), mix.astype(np.float32), SR)
def db(x): return 20 * np.log10(np.sqrt(np.mean(x ** 2)) + 1e-9)
for i in range(0, 15, 1):
    sl = slice(i * SR, (i + 1) * SR)
    print(f'{i:2d}s  music {db(m[sl] * .5):6.1f}  pen {db(pen[sl]):6.1f}')
print('out/mix.wav', mix.shape, 'peak', round(float(np.abs(mix).max()), 3))
