// Camera keys: t seconds, (x, y) composition centre in paper units, z zoom (1 ≈ the whole picture), r roll in degrees,
// f follow weight (0 = composed, 1 = locked to the nib), c how strongly the nib is kept in frame (0 lets it run out).
export const CAM = [
  { t: -1.0, x: -1500, y: -30, z: 2.7, r: 0, f: .9 },
  { t: 2.4, x: -640, y: -40, z: 2.3, r: 0, f: .85 },          // following the sea line: lateral scroll
  { t: 3.4, x: -270, y: -110, z: 2.1, r: -2, f: .6 },          // a crest curls up into the tail
  { t: 4.6, x: -20, y: -220, z: 2.1, r: 2, f: .55 },           // the back, then the neck: roll with the S
  { t: 5.6, x: 60, y: -330, z: 2.3, r: 4, f: .5 },
  { t: 6.2, x: 112, y: -398, z: 3.1, r: 1, f: .2 },            // the head, composed: crown and eye
  { t: 6.75, x: 140, y: -396, z: 3.1, r: 0, f: .22 },
  { t: 7.3, x: 410, y: -346, z: 2.8, r: 0, f: .7 },            // the dash along the beak
  { t: 7.75, x: 474, y: -322, z: 3.6, r: 0, f: 0 },            // the stop: macro on the hook
  { t: 9.3, x: 480, y: -320, z: 4.3, r: 0, f: 0 },             // very slow push-in through the silence
  { t: 10.4, x: 330, y: -288, z: 2.7, r: 0, f: .3 },           // the gold pouch
  { t: 11.6, x: 240, y: -268, z: 2.4, r: 0, f: .35 },
  { t: 12.6, x: 200, y: -150, z: 2.0, r: 0, f: .5, c: 1 },     // down the neck to the water
  { t: 13.3, x: 160, y: -170, z: 1.6, r: 0, f: .15, c: 0 },    // let the line go
  { t: 14.25, x: 70, y: -190, z: 1.04, r: 0, f: 0, c: 0 },     // one continuous pull-back: the whole picture
  { t: 15.5, x: 66, y: -190, z: 1.02, r: 0, f: 0, c: 0 },
];
