# The Sea Without Water / 沒有水的海

A 15-second original Golden Pelican bicycle test in lemo-opuscar's Art Deco style. Continuity: Crystal's original “The singing dune,” the destination Murphy chose. This is a new interpretation, not footage extracted from the original.

## Sources and workflow
Crystal32378/lemo-opuscar PR #1 head 5fb4c40c16013e90f472d5bc9e9804a133fd7cfa was inspected on 2026-11-04. PR open, not merged. Read AGENTS.md, DIRECTOR.md, TECHNIQUE.md, and styles/art-deco/STYLE.md; treatment preceded DEMO.md. Followed the guides' explicitly permitted own-stack workflow with existing Canvas, NumPy and ffmpeg. No setup.sh, installs, paid services, downloaded artwork, or copied demo code. Source: https://github.com/Crystal32378/lemo-opuscar/pull/1

Original scene: https://crystal32378.github.io/golden-pelican/#dune
Continuity reference: https://github.com/Crystal32378/golden-pelican/blob/main/README.en.md
The scene has no named real-world location. This film makes no geographic claim and contains no maps.

## Story choice
Three candidates: a bell waking a sun; a wheel becoming a moon; revisiting the sea that is not there. Chosen: the third, following Crystal's clarification to preserve the original singing-dune imagery rather than introduce an unrelated gag.
Logline: A golden pelican pedals toward a shimmering sea, coasts and looks, and finds only singing sand and a quiet fennec companion.
Setup: desire and movement. Turn: the sea vanishes. Ending: a companion remains.

## Look
Art Deco warm lacquer, gold engraved rims, banded metal and directional airbrush, centre-axis sun, stepped architectural border. A red bicycle is the sole large saturated accent. Mirage uses a subdued cool jewel tone. Character poses on twos, camera and lighting on ones. 1920x1080, 24 fps. No title lettering, narration, subtitle, or watermark.
Benchmark: Cassandre's geometric scale and architectural Art Deco ornament; no particular composition, building, character, melody or lettering copied. An original anatomically recognizable pelican with long bill, throat pouch and sand goggles; original oversized-eared fennec.

## Shot and beat map
0–3 s: pull back from the large rider and wheel, keep the distant sea in view. Pelican pedals, sand shifts down the lee face, wheels turn, rut trails behind.
3–5 s: modest push on rider; a last pedal phrase before a breath.
5–9 s: pedals stop, wheels coast, head rises to look. The distant sea recedes and disappears gradually from 6–9 s. Music falls almost silent 8.5–9 s.
9–15 s: gentle pullback and downward reframing reveal the waiting fennec and the empty sand. Gold sun and fan geometry remain stable. Hold the final feeling, without a punchline.

## Sound
Original spare 120 bpm celesta-like/reed-like jazz phrase, plucked bass, 88 Hz singing-sand tone and modest upper harmonics, quiet filtered wind, granular tire clicks, restrained bell-like accents. Synthesized from equations, no samples or copied music. Breaths at 4.5–5 s and 8.5–9 s. Sound tails cross camera changes. Final two-pass loudness normalization targets -14 LUFS and -1.2 dBTP. No voice.

## Bicycle and sand limits
Wheel angle = world distance / radius (145 pixels per travel unit; radius 116 pixels). Pedals stop at 5 s while wheel rotation continues with slowing travel. Foot positions remain attached to the crank. A single rut is visible in this side profile: the front and rear wheels share the same path. Tread marks move with travel distance and fade with age. Sand tongues accelerate downward along the lee face. These are deterministic stylized kinematics, not a rigid-body bicycle or granular-material physics simulation. No claim of physically validated sand mechanics.

## Originality review
Unlike the Art Deco demo's hotel delivery deadline, this is one quiet desert encounter. Opening is a rider in motion, not a title explosion; no building, letter, bellboy, elevator, staircase, announcer or lettering. Signature is the evaporating sea and sand rut, not a counted sign reveal. Camera is a continuous restrained pull/push/pull, score a spare reflective miniature, ending companionship rather than a machinery gag. All six comparison categories differ.
