#!/bin/sh
set -eu
cd "$(dirname "$0")"
node render-native.cjs
python3 score.py
ffmpeg -y -framerate 24 -i frames/%04d.jpg -i mix.wav -c:v libx264 -preset medium -crf 18 -pix_fmt yuv420p -af 'loudnorm=I=-14:TP=-1.2:LRA=11:measured_I=-23.97:measured_TP=-10.14:measured_LRA=2.80:measured_thresh=-34.66:offset=0.19:linear=true' -c:a aac -b:a 192k -ar 48000 -t 15 -movflags +faststart Sea-Without-Water.mp4
