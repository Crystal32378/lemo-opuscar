import numpy as np, wave
from pathlib import Path
SR=48000; D=15; n=SR*D; x=np.zeros((n,2)); rng=np.random.default_rng(73)
def add(v,t,g=.2,pan=0):
 i=int(t*SR); v=v[:max(0,n-i)];x[i:i+len(v),0]+=v*g*(.8-pan*.3);x[i:i+len(v),1]+=v*g*(.8+pan*.3)
def note(f,d,kind='bell'):
 t=np.arange(int(SR*d))/SR
 if kind=='bell':return (np.sin(2*np.pi*f*t)*np.exp(-t*4)+.3*np.sin(2*np.pi*f*2.76*t)*np.exp(-t*8)+.12*np.sin(2*np.pi*f*5.4*t)*np.exp(-t*16))*np.minimum(t*200,1)
 if kind=='bass':return (np.sin(2*np.pi*f*t)+.4*np.sin(4*np.pi*f*t)+.15*np.sin(6*np.pi*f*t))*np.exp(-t*8)*np.minimum(t*100,1)
 if kind=='reed':return sum(np.sin(2*np.pi*f*k*t+.005*np.sin(t*30))*1/k**1.8 for k in [1,3,5,7])*np.minimum(t*12,1)*np.minimum((d-t)*7,1)*.5
# Original spare jazz phrase, rather than cinematic pads. A celesta/reed duet.
mel=[(0,62),(.75,65),(1.5,69),(2.25,67),(3,65),(3.75,62),(5.25,69),(6,72),(6.75,74),(9,74),(9.75,72),(10.5,69),(11.25,65),(12,67),(13,62)]
for t,m in mel:add(note(440*2**((m-69)/12),1.2),t,.22,-.35)
for t,m in [(1,50),(2,57),(3,53),(4,57),(5.5,50),(6.5,57),(9,46),(10,53),(11,50),(12,57),(13,50)]:add(note(440*2**((m-69)/12),.65,'bass'),t,.18,.15)
for t,m,d in [(0.5,62,1.1),(2.5,65,1.2),(5.5,69,1),(9.0,67,1.4),(11,65,1.2),(13,62,1.5)]:add(note(440*2**((m-69)/12),d,'reed'),t,.1,.35)
# Singing sand: tonal 88 Hz with modest harmonics and very quiet wind.
t=np.arange(n)/SR
speed=np.where(t<5,1,np.where(t<9,.48,.3));hum=(np.sin(2*np.pi*88*t)+.35*np.sin(2*np.pi*176*t)+.18*np.sin(2*np.pi*264*t))*.043*(.3+.7*speed)*np.minimum(t*2,1)
wind=rng.normal(0,1,n);wind=np.convolve(wind,np.ones(50)/50,'same')*.022
add(hum+wind,0,1)
# Sand grains, tire clicks; every step shares the same travel law as the picture.
for at in np.arange(.15,5,.5):
 d=.16;u=np.arange(int(SR*d))/SR;v=rng.normal(0,1,len(u))*np.exp(-u*24);add(v,at,.015,-.15)
for at in [5,9]:add(note(780 if at==5 else 520,.8),at,.10,.3)
# Two breaths before coasting and the disappearing sea.
for a,b in [(4.5,5),(8.5,9)]:
 mask=(t>=a)&(t<b); x[mask]*=.05
# Tiny fennec curiosity sound, no speech.
add(note(1174,.5),12.5,.045,.65)
fade=np.minimum(t/.05,1)*np.minimum((D-t)/.6,1);x*=fade[:,None];x=np.tanh(x)*.8
with wave.open(str(Path(__file__).parent/'mix.wav'),'wb') as f:f.setnchannels(2);f.setsampwidth(2);f.setframerate(SR);f.writeframes((np.clip(x,-1,1)*32767).astype('<i2').tobytes())
