# Validation

Final MP4: 15.000 seconds, 1920x1080, 24 fps, 360 frames, H.264 + stereo AAC at 48 kHz.
Final measured loudness: -14.0 LUFS, 3.0 LU loudness range, -1.2 dBFS true peak.
ffmpeg decoded the complete file without errors. No blackdetect intervals found at duration 0.05s and pixel threshold 0.10.
Visually inspected representative rendered frames from both passes, including opening, pedal stop, disappearing sea, and final frame. Corrected initial cropping and removed whole-bicycle bob so tires remain on their contact line. No claim of full real-time audiovisual playback review.
All animation is deterministic. Original source uses no external network resources.
The frame/track geometry is stylized kinematics, not physically validated sand simulation. The very low sand hum may be less audible on phone speakers.
