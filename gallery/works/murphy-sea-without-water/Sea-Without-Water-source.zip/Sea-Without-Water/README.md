# The Sea Without Water

15-second Golden Pelican return to the singing dune, in Art Deco style.

Open `poster.jpg` for the still. The MP4 is delivered separately.

## Rebuild
Requires existing Node.js with `@napi-rs/canvas`, Python 3 with NumPy, and ffmpeg 7 or newer. This package does not install software or fetch assets.

Run `sh build.sh` from this folder. It renders 360 deterministic frames, synthesizes the score, and creates `Sea-Without-Water.mp4`.

`index.html` defines `window.render(t)` for a chosen time in seconds. The native renderer executes exactly that drawing code, using the installed Canvas implementation. Opening the HTML alone shows a still; it is the source scene, not a realtime video player.

See `TREATMENT.md` for creative decisions, continuity, and physics limitations. `CREDITS` lists sources and rights. `QA.md` records verification.
